# CALIBURN Paper Figures

This directory contains scripts to generate the 5 figures for the CALIBURN paper.

## Files

| File | Description |
|---|---|
| `fig1_architecture_drawio_spec.md` | Specification for the architecture diagram (draw.io tool) |
| `fig2_pr_comparison_litnet.py` | Generates precision-recall operating points figure (data-driven) |
| `fig3_regime_sensitivity.py` | Generates the regime-sensitivity bar chart across 3 datasets |
| `fig4_burn_rate_illustration.py` | Generates synthetic multi-window burn-rate illustration |
| `fig5_bocpd_posterior.py` | Generates synthetic BOCPD posterior visualization |
| `README.md` | This file |

## Prerequisites

```bash
pip install --break-system-packages numpy pandas matplotlib
```

(Or use a virtualenv: `python -m venv venv && source venv/bin/activate && pip install numpy pandas matplotlib`)

## Running on the AWS VM

Copy the four `.py` scripts to your repo:

```bash
cd ~/work/rcbsid_v7
mkdir -p scripts/figures
# (Copy the four .py files into scripts/figures/)

# Run all data-driven figures from the repo root so paths work
python scripts/figures/fig2_pr_comparison_litnet.py
python scripts/figures/fig3_regime_sensitivity.py
python scripts/figures/fig4_burn_rate_illustration.py
python scripts/figures/fig5_bocpd_posterior.py
```

This produces 8 output files in `figures/`:

```
figures/
  fig2_pr_comparison_litnet.pdf
  fig2_pr_comparison_litnet.png
  fig3_regime_sensitivity.pdf
  fig3_regime_sensitivity.png
  fig4_burn_rate_illustration.pdf
  fig4_burn_rate_illustration.png
  fig5_bocpd_posterior.pdf
  fig5_bocpd_posterior.png
```

The PDFs are vector format and are what you should include in the LaTeX source. The PNGs are 300 DPI rasters useful for previewing or for venues that don't accept vector.

## Including in LaTeX

In your `main.tex`, add `\usepackage{graphicx}` to the preamble (already done).

Add figures at the appropriate places in the manuscript:

```latex
\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{figures/fig2_pr_comparison_litnet.pdf}
  \caption{LITNET-2020 precision-recall operating points across all evaluated methods.
  CALIBURN (red star) achieves a precision-recall point in the upper-right quadrant
  unmatched by any baseline.}
  \label{fig:pr-litnet}
\end{figure}

\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{figures/fig3_regime_sensitivity.pdf}
  \caption{Regime sensitivity: AUC-PR vs attack prevalence across the three NIDS datasets.
  CALIBURN dominates at rare-attack regime (LITNET, 5.2\%), remains the best streaming
  method at moderate prevalence (CICIDS, 22.06\%), and collapses with all streaming methods
  at high prevalence (UNSW, 64\%). The pattern supports the regime-sensitivity hypothesis
  in Section~\ref{sec:disc-positioning}.}
  \label{fig:regime-sensitivity}
\end{figure*}

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{figures/fig4_burn_rate_illustration.pdf}
  \caption{Multi-window burn-rate alerting on a synthetic event stream. (a) shows a
  brief noise burst at $t{=}120$ and a sustained attack at $t{=}300$. (b) shows that
  the short-window burn rates spike with the noise burst, but the long windows do not
  cross threshold, demonstrating dual-window protection from transient noise. (c) shows
  alerts firing only when both windows of a level exceed their burn threshold.}
  \label{fig:burn-rate}
\end{figure}

\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{figures/fig5_bocpd_posterior.pdf}
  \caption{Truncated BOCPD posterior dynamics on a synthetic stream with one
  change-point at $t{=}300$. (a) Observation stream with mean shift. (b) Run-length
  posterior $P(r_t \mid x_{1:t})$ visualized as a heatmap; the dominant ridge representing
  the current run length grows with time and resets at the change-point. (c) CALIBURN
  anomaly score $s_t = P(r_t \leq 5 \mid x_{1:t})$ spikes sharply at the true change-point
  and crosses the cost-derived threshold $\tau^* = 0.091$ corresponding to cost ratio $C{=}10$.}
  \label{fig:bocpd-posterior}
\end{figure*}
```

Use `\begin{figure}` (single column) for figures 2 and 4 (single-column).
Use `\begin{figure*}` (full width) for figures 3 and 5 (double-column).

## Where to place figures in the paper

| Figure | Section | Approximate position |
|---|---|---|
| Fig 1 (architecture) | §3 Method, opening | Right after the introductory paragraph of §3 |
| Fig 2 (PR points) | §5 Results, sub §5.1 | After Table 1 |
| Fig 3 (regime sensitivity) | §5 Results, sub §5.4 | Beginning of §5.4 cross-dataset comparison |
| Fig 4 (burn rate) | §3 Method, sub §3.4 | After the burn-rate equation and threshold table |
| Fig 5 (BOCPD posterior) | §3 Method, sub §3.2 | After Algorithm 1 |

## Customizing

**Change figure size:** Edit `figsize=(...)` in each script. Default is 3.5" wide single-column or 7.0" wide double-column.

**Change colors:** All scripts use the same matplotlib color palette. Edit the `METHOD_STYLE` dict (fig2) or the explicit color hex codes throughout.

**Change DPI:** All figures save at 300 DPI by default. For final submission, consider 600 DPI: edit `mpl.rcParams["savefig.dpi"] = 600`.

**Change fonts:** Default is Helvetica/Arial sans-serif. To match Elsevier body text (which is often Times-like), change:
```python
"font.family": "serif",
"font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
```

## Reproducibility notes

- Figures 2 and 3 are generated entirely from your CSV files. They are deterministic.
- Figures 4 and 5 use synthetic data with `np.random.seed(42)` and `np.random.seed(11)` respectively. They are deterministic.
- All four scripts are self-contained and do not require any saved models or per-flow scores from your experiments.
