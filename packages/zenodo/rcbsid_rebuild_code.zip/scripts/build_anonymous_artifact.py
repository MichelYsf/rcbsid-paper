#!/usr/bin/env python
"""Build the anonymized artifact zip for double-blind review, and PROVE it is anonymous.

Double-anonymous review requires the supplementary artifact to carry no
author-identifying strings. Assembling it by hand and eyeballing is how a
name ships; this script assembles the zip from an allowlist, scrubs the two
files that legitimately carry identity (CITATION.cff is excluded outright;
README.md has its repository URL redacted), replaces the machine username in
archived manifest paths, and then FAILS if any identifying token survives
anywhere in the zip.
"""
from __future__ import annotations

import io
import re
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "packages/dtrap/artifact_anonymous.zip"

IDENTIFYING = [b"Youssef", b"youssef", b"MichelYsf", b"Michel", b"michel",
               b"hotmail", b"0664-8228", b"0664-8224", b"CYBERWIZARD",
               b"camich289",
               # The repository directory name and the branch name survive
               # inside archived absolute paths and in prose even after the
               # machine username is replaced. "rcbsid-paper" is the name of
               # the public GitHub repository, so a search for it names the
               # author; the branch name pins the same repository. Neither
               # appears in the manuscript, so a referee has no innocent
               # reason to have seen either.
               b"rcbsid-paper", b"rebuild/honest-v1",
               # The two public preprints resolve to listings that name the
               # author, the IEEE record id names a submission of theirs, and
               # the former title and the project codename are one web search
               # from either. TMLR's guide: double blind is maintained by not
               # linking to another version that includes the authors' names.
               b"2605.24696", b"2510.09619", b"TDSC-2025-10-1842",
               b"Operationally Calibrated Streaming",
               # every case form of the project codename, including the former
               # module name; the artifact carries that module under a neutral
               # name, with every import, identifier, path and prose mention
               # rewritten consistently (see codename_map below)
               b"CALIBURN", b"Caliburn", b"caliburn",
               # Zenodo record ids: each resolves to a page naming the author
               b"22673735", b"22638195", b"22213264", b"20074590",
               b"20074589", b"zenodo.org"]

INCLUDE_DIRS = ["src", "scripts", "tests"]
INCLUDE_FILES = [
    "requirements.txt", "README.md", "SCOPE_DECISIONS.md",
    "AUDIT_FINDINGS.md", "CLAIM_LEDGER.md", "SUPERSEDED.md",
    "REBUILD_DONE.md", "findings_contrast.md", "findings_prevalence.md",
    "findings_score_threshold.md", "findings_bocpd_ablation.md",
    "findings_contributions.md", "findings_streams.md",
    "findings_review_analyses.md", "findings_referee_analyses.md",
    "findings_bootstrap_robustness.md", "findings_ecod_composition.md",
    "paper/main.tex", "paper/numbers.tex", "paper/references.bib",
    # the unmodified TMLR template, so the source compiles from the artifact
    "paper/tmlr.sty", "paper/tmlr.bst", "paper/fancyhdr.sty",
    "paper/figures/figure_manifest.json",
    "results/construction_contrast.csv", "results/prevalence_sweep_cicids.csv",
    "results/table_construction_contrast.tex",
    "results/table_prevalence_sweep.tex",
    "data/raw/natural/EXPECTED_SHA256.txt",
]
EXCLUDE_NAMES = {"CITATION.cff", "build_anonymous_artifact.py",
                 # cloud/ops infrastructure, not analysis: these carry machine
                 # paths and the named GitHub remote, and a reviewer needs none
                 # of them to reproduce the results locally
                 "autopilot_launch.cmd", "autopilot_runner.py",
                 "ec2_bootstrap.sh", "ec2_rebuild_bootstrap.sh",
                 "phase5_bring_home.sh", "local_puller.sh",
                 "pull_rebuild_results.py", "teardown_rebuild_instance.py",
                 "apply_power_settings.cmd", "rebuild_runner.py",
                 "build_arxiv_variant.py"}
EXCLUDE_SUFFIX = {".pyc", ".pdf", ".zip", ".tar.gz"}


CODE_SUFFIXES = (".py", ".sh", ".cmd", ".cfg", ".yaml", ".yml", ".json", ".csv", ".tex", ".bib")


def codename_map(rel: str, data: bytes) -> bytes:
    """The project codename is the title of the named preprint, so it must not
    ship. In code it is an identifier (a module name that is an import target,
    a function name, a constant, an environment-variable name), so it is mapped
    case-preservingly to a neutral identifier and the module file is renamed
    to match (see anonymize_path). In prose, the module path takes the same
    neutral name so the text still points at a file that exists, and every
    other mention becomes a placeholder."""
    if rel.endswith(CODE_SUFFIXES):
        data = data.replace(b"CALIBURN", b"CODENAME")
        data = data.replace(b"Caliburn", b"Codename")
        data = data.replace(b"caliburn", b"codename")
        return data
    if rel.endswith((".md", ".txt")):
        data = data.replace(b"caliburn_variants", b"codename_variants")
        data = re.sub(rb"(?i)caliburn", b"[codename-redacted-for-review]", data)
        return data
    return data


def anonymize_path(rel: str) -> str:
    """Entry names inside the zip: the module and its test are renamed to the
    neutral identifier the code now imports."""
    return rel.replace("caliburn", "codename")


def scrub(rel: str, data: bytes) -> bytes:
    text_like = rel.endswith((".py", ".md", ".txt", ".tex", ".bib", ".json",
                              ".csv", ".cfg", ".yaml", ".yml", ".sh"))
    if not text_like:
        return data
    # machine username inside archived absolute paths
    data = data.replace(b"CYBERWIZARD", b"ANON")
    data = data.replace(b"camich289", b"ANON")
    # ... and the two path-shaped identifiers the username replacement leaves
    # behind: 93 of 231 entries carried "projects/rcbsid-paper" after the
    # username was scrubbed, which is the public repository's name.
    data = data.replace(b"rcbsid-paper", b"[repo-redacted-for-review]")
    data = data.replace(b"rebuild/honest-v1", b"[branch-redacted-for-review]")
    # the named preprints, in every form they are written
    data = re.sub(rb"arXiv:\s*2605\.24696(?:v\d)?", b"[preprint-id-redacted-for-review]", data)
    data = re.sub(rb"arXiv:\s*2510\.09619(?:v\d)?", b"[companion-id-redacted-for-review]", data)
    data = data.replace(b"2605.24696", b"[preprint-id-redacted-for-review]")
    data = data.replace(b"2510.09619", b"[companion-id-redacted-for-review]")
    data = data.replace(b"TDSC-2025-10-1842", b"[record-id-redacted-for-review]")
    data = data.replace(b"Operationally Calibrated Streaming",
                        b"[former-title-redacted-for-review]")
    # the underscore form the tarball file names use
    data = data.replace(b"2605_24696", b"[preprint-id-redacted-for-review]")
    data = data.replace(b"2510_09619", b"[companion-id-redacted-for-review]")
    data = codename_map(rel, data)
    # Zenodo record identifiers resolve to a page naming the author, so the
    # double-anonymous artifact redacts them wherever the correction log or
    # README carries them; the scan below then proves none survive.
    for doi in (b"10.5281/zenodo.22673735", b"10.5281/zenodo.22638195",
                b"10.5281/zenodo.22213264", b"10.5281/zenodo.20074590",
                b"10.5281/zenodo.20074589"):
        data = data.replace(doi, b"[doi-redacted-for-review]")
    # any other identifier in the record lineage's prefix, in either DOI form
    data = re.sub(rb"(?:doi:|https?://doi\.org/)?10\.5281/zenodo\.\d+",
                  b"[doi-redacted-for-review]", data)
    data = re.sub(rb"https?://(?:www\.)?zenodo\.org/\S*",
                  b"[zenodo-url-redacted-for-review]", data)
    if rel == "README.md":
        data = re.sub(rb"https://github\.com/\S+", b"[public-repo-redacted-for-review]", data)
        data = data.replace(b"MichelYsf", b"[redacted]")
        # CITATION.cff is excluded from this zip; do not point a reviewer at it
        data = data.replace(b"See `CITATION.cff`.",
                            b"The citation file is withheld from this anonymized copy.")
    if rel == "paper/main.tex":
        pass  # already the anonymous variant
    return data


def main() -> int:
    files: list[Path] = []
    for d in INCLUDE_DIRS:
        files += [p for p in (ROOT / d).rglob("*") if p.is_file()]
    files += [ROOT / f for f in INCLUDE_FILES if (ROOT / f).exists()]
    files += [p for p in (ROOT / "results/manifests").rglob("*.json")]
    # Figures are the one PDF class that ships: deterministic renders of
    # archived values, metadata-stripped, so that check_figures.py can run
    # inside the extracted artifact (SCOPE_DECISIONS rule 12).
    files += [p for p in (ROOT / "paper/figures").glob("*.pdf")]
    # The retirement reasons live in a README beside the retired manifests, not
    # in a manifest, so a *.json glob silently drops them (B8/CI-31).
    _sup = ROOT / "results/manifests/superseded/README.md"
    if _sup.exists():
        files.append(_sup)

    # Every file the claim ledger cites must be IN the artifact: a referee who
    # extracts the zip and runs the ledger check is the first reader, and until
    # this was added that check failed on the artifact's own missing evidence.
    _ledger = ROOT / "CLAIM_LEDGER.md"
    if _ledger.exists():
        import re as _re
        _cited = set(_re.findall(r"file:([A-Za-z0-9_./-]+)",
                                 _ledger.read_text(encoding="utf-8")))
        _missing = []
        for _c in sorted(_cited):
            _p = ROOT / _c
            if not _p.exists():
                continue
            if _p not in files:
                files.append(_p)
                _missing.append(_c)
        if _missing:
            print("added %d ledger-cited file(s) the include list omitted: %s"
                  % (len(_missing), ", ".join(_missing)))

    leaks: list[str] = []
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(files)):
            rel = p.relative_to(ROOT).as_posix()
            if p.name in EXCLUDE_NAMES or (p.suffix in EXCLUDE_SUFFIX
                                           and not rel.startswith("paper/figures/")):
                continue
            if "__pycache__" in rel or "/_dryrun/" in rel:
                continue
            data = scrub(rel, p.read_bytes())
            rel_out = anonymize_path(rel)
            for tok in IDENTIFYING:
                if tok in data:
                    leaks.append(rel + " contains " + tok.decode(errors="replace"))
                if tok in rel_out.encode("utf-8"):
                    leaks.append(rel + " is NAMED with " + tok.decode(errors="replace"))
            # Preserve each file's modification time. writestr() with a bare
            # name stamps every entry with the build clock, which made the
            # extracted artifact's manifests look newer than the figures they
            # produced and failed check_figures.py there (rule 12).
            info = zipfile.ZipInfo("artifact/" + rel_out,
                                   date_time=time.localtime(p.stat().st_mtime)[:6])
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, data)

    n = len(zipfile.ZipFile(OUT).namelist())
    print("wrote %s (%d files, %d bytes)" % (OUT.name, n, OUT.stat().st_size))
    if leaks:
        for l in sorted(set(leaks))[:20]:
            print("  IDENTITY LEAK  " + l)
        print("FAILED - the artifact is not anonymous. Not shippable.")
        OUT.unlink()
        return 1
    print("PASSED - no identifying token survives in the artifact.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
