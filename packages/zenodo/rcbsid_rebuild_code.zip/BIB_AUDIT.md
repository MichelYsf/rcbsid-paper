# BIB_AUDIT: bibliography verification, 2026-09-03

Every entry in `paper/references.bib` was verified against a registrar or
publisher record (Crossref, DBLP, the arXiv API, the GitHub API, or the
publisher page). This file records every field that changed, with the
record it was checked against. Conventions adopted: every cited work has an
entry and every entry is cited; titles in title case with acronyms and proper
nouns brace-protected; a preprint is cited as its version of record where one
exists, with the arXiv identifier kept in the note; no entry carries an
unverified status word.

## Registrar discrepancies corrected (kept entries)

| entry | field | old value | new value | source |
|---|---|---|---|---|
| `damasevicius2020litnet` | authors | and others | Damasevicius, Robertas and Venckauskas, Algimantas and Grigaliunas, Sarunas and Toldinas, Jevgenijus and Morkevicius, Nerijus and Aleliunas, Tautvydas and Smuik | https://api.crossref.org/works/10.3390/electronics9050800 |
| `damasevicius2020litnet` | doi | (absent) | 10.3390/electronics9050800 | https://api.crossref.org/works/10.3390/electronics9050800 |
| `beyer2016sre` | title | Site Reliability Engineering | Site Reliability Engineering: How Google Runs Production Systems | https://openlibrary.org/isbn/9781491929124.json |
| `beyer2016sre` | editor | (absent; the four names are given as author) | Beyer, Betsy and Jones, Chris and Petoff, Jennifer and Murphy, Niall Richard (editors) | https://openlibrary.org/isbn/9781491929124.json |
| `ring2019datasets` | volume | (absent) | 86 | https://api.crossref.org/works/10.1016/j.cose.2019.06.005 |
| `ring2019datasets` | pages | (absent) | 147--167 | https://api.crossref.org/works/10.1016/j.cose.2019.06.005 |
| `ring2019datasets` | doi | (absent) | 10.1016/j.cose.2019.06.005 | https://api.crossref.org/works/10.1016/j.cose.2019.06.005 |
| `li2020copod` | authors | and others | Li, Zheng and Zhao, Yue and Botta, Nicola and Ionescu, Cezar and Hu, Xiyang | https://api.crossref.org/works/10.1109/ICDM50108.2020.00135 |
| `li2020copod` | venue | IEEE ICDM | 2020 IEEE International Conference on Data Mining (ICDM) | https://api.crossref.org/works/10.1109/ICDM50108.2020.00135 |
| `li2020copod` | pages | (absent) | 1118--1123 | https://api.crossref.org/works/10.1109/ICDM50108.2020.00135 |
| `li2020copod` | doi | (absent) | 10.1109/ICDM50108.2020.00135 | https://api.crossref.org/works/10.1109/ICDM50108.2020.00135 |
| `li2020copod` | publisher | (absent) | IEEE | https://api.crossref.org/works/10.1109/ICDM50108.2020.00135 |
| `breunig2000lof` | authors | Sander, Jorg | Sander, J{\"o}rg | https://api.crossref.org/works/10.1145/342009.335388 |
| `breunig2000lof` | venue | SIGMOD | Proceedings of the 2000 ACM SIGMOD International Conference on Management of Data | https://api.crossref.org/works/10.1145/342009.335388 |
| `breunig2000lof` | pages | (absent) | 93--104 | https://api.crossref.org/works/10.1145/342009.335388 |
| `breunig2000lof` | doi | (absent) | 10.1145/342009.335388 | https://api.crossref.org/works/10.1145/342009.335388 |
| `breunig2000lof` | publisher | (absent) | ACM | https://api.crossref.org/works/10.1145/342009.335388 |
| `catillo2023hype` | venue | 53rd Annual IEEE/IFIP International Conference on Dependable Systems and Networks -- Supplemental Volume (DSN-S) | 2023 53rd Annual IEEE/IFIP International Conference on Dependable Systems and Networks - Supplemental Volume (DSN-S) | https://api.crossref.org/works/10.1109/DSN-S58398.2023.00038 |
| `catillo2023hype` | publisher | (absent) | IEEE | https://api.crossref.org/works/10.1109/DSN-S58398.2023.00038 |
| `arp2022dosdonts` | venue | 31st USENIX Security Symposium | 31st USENIX Security Symposium (USENIX Security 22) | https://www.usenix.org/conference/usenixsecurity22/presentation/arp |
| `arp2022dosdonts` | publisher | (absent) | USENIX Association | https://www.usenix.org/conference/usenixsecurity22/presentation/arp |
| `cao2024revisiting` | title | Revisiting Streaming Anomaly Detection: Benchmark and Evaluation | Revisiting streaming anomaly detection: benchmark and evaluation | https://link.springer.com/article/10.1007/s10462-024-10995-w |
| `cao2024revisiting` | year | 2024 | 2025 | https://link.springer.com/article/10.1007/s10462-024-10995-w |
| `cao2024revisiting` | number | (absent) | 1 | https://api.crossref.org/works/10.1007/s10462-024-10995-w |
| `cao2024revisiting` | pages | (absent) | 8 | https://link.springer.com/article/10.1007/s10462-024-10995-w |
| `vovk2005alrw` | entry_type | article | book | https://api.crossref.org/works/10.1007/b106715 |
| `vovk2005alrw` | venue | journal={Springer} | publisher={Springer}, address={New York} (a book has no journal field) | https://api.crossref.org/works/10.1007/b106715 |
| `vovk2005alrw` | doi | (absent) | 10.1007/b106715 | https://api.crossref.org/works/10.1007/b106715 |
| `davis2006prroc` | venue | 23rd International Conference on Machine Learning (ICML) | Proceedings of the 23rd International Conference on Machine Learning (ICML '06) | https://api.crossref.org/works/10.1145/1143844.1143874 |
| `davis2006prroc` | publisher | (absent) | ACM Press | https://api.crossref.org/works/10.1145/1143844.1143874 |
| `olszewski2023reproducibility` | venue | ACM SIGSAC Conference on Computer and Communications Security (CCS) | Proceedings of the 2023 ACM SIGSAC Conference on Computer and Communications Security (CCS '23) | https://api.crossref.org/works/10.1145/3576915.3623130 |
| `olszewski2023reproducibility` | publisher | (absent) | ACM | https://api.crossref.org/works/10.1145/3576915.3623130 |
| `han2022adbench` | authors | Jiang, Mingqi | Jiang, Minqi | https://api.crossref.org/works/10.52202/068431-2329 |
| `han2022adbench` | doi | (absent) | 10.52202/068431-2329 | https://api.crossref.org/works/10.52202/068431-2329 |
| `han2022adbench` | pages | (absent) | 32142--32159 | https://api.crossref.org/works/10.52202/068431-2329 |
| `han2022adbench` | volume | (absent) | 35 | https://api.crossref.org/works/10.52202/068431-2329 |
| `han2022adbench` | venue | Advances in Neural Information Processing Systems (NeurIPS) | Advances in Neural Information Processing Systems 35 (NeurIPS 2022), Datasets and Benchmarks Track | https://proceedings.neurips.cc/paper_files/paper/2022/hash/cf93972b116ca5268827d575f2cc226b-Abstract-Datasets_and_Benchmarks.html |
| `han2022adbench` | publisher | (absent) | Neural Information Processing Systems Foundation, Inc. (NeurIPS) | https://api.crossref.org/works/10.52202/068431-2329 |
| `adams2007bocpd` | doi | (absent) | 10.48550/arXiv.0710.3742 | https://api.datacite.org/dois/10.48550/arXiv.0710.3742 |
| `adams2007bocpd` | arxiv | (absent; only embedded in journal field) | 0710.3742 | https://export.arxiv.org/api/query?id_list=0710.3742 |
| `tan2011hst` | venue | IJCAI | Proceedings of the Twenty-Second International Joint Conference on Artificial Intelligence | https://www.ijcai.org/proceedings/2011 |
| `tan2011hst` | pages | (absent) | 1511-1516 | https://dblp.org/search/publ/api?q=Fast%20Anomaly%20Detection%20for%20Streaming%20Data%20Tan%20Ting%20Liu&format=json |
| `tan2011hst` | doi | (absent) | 10.5591/978-1-57735-516-8/IJCAI11-254 | https://www.ijcai.org/proceedings/2011 |
| `tan2011hst` | publisher | (absent) | AAAI Press / International Joint Conferences on Artificial Intelligence | https://www.ijcai.org/proceedings/2011 |
| `tan2011hst` | authors | Liu, Fei Tony | Liu, Tony Fei (byline as printed on the paper and on ijcai.org; DBLP normalises the same author to 'Fei Tony Liu') | https://www.ijcai.org/Proceedings/11/Papers/254.pdf |
| `mirsky2018kitsune` | venue | NDSS | Proceedings 2018 Network and Distributed System Security Symposium | https://api.crossref.org/works/10.14722/ndss.2018.23204 |
| `mirsky2018kitsune` | doi | (absent) | 10.14722/ndss.2018.23204 | https://api.crossref.org/works/10.14722/ndss.2018.23204 |
| `mirsky2018kitsune` | publisher | (absent) | Internet Society | https://api.crossref.org/works/10.14722/ndss.2018.23204 |
| `mirsky2018kitsune` | arxiv | (absent) | 1802.09089 | https://export.arxiv.org/api/query?id_list=1802.09089 |
| `pevny2016loda` | authors | Pevny, Tomas | Pevný, Tomáš | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `pevny2016loda` | volume | (absent) | 102 | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `pevny2016loda` | number | (absent) | 2 | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `pevny2016loda` | pages | (absent) | 275-304 | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `pevny2016loda` | doi | (absent) | 10.1007/s10994-015-5521-0 | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `pevny2016loda` | publisher | (absent) | Springer Science and Business Media LLC | https://api.crossref.org/works/10.1007/s10994-015-5521-0 |
| `manzoor2018xstream` | venue | KDD | Proceedings of the 24th ACM SIGKDD International Conference on Knowledge Discovery & Data Mining | https://api.crossref.org/works/10.1145/3219819.3220107 |
| `manzoor2018xstream` | pages | (absent) | 1963-1972 | https://api.crossref.org/works/10.1145/3219819.3220107 |
| `manzoor2018xstream` | doi | (absent) | 10.1145/3219819.3220107 | https://api.crossref.org/works/10.1145/3219819.3220107 |
| `manzoor2018xstream` | publisher | (absent) | ACM | https://api.crossref.org/works/10.1145/3219819.3220107 |
| `guha2016rrcf` | venue | ICML | Proceedings of The 33rd International Conference on Machine Learning (PMLR vol. 48) | https://proceedings.mlr.press/v48/guha16.html |
| `guha2016rrcf` | volume | (absent) | 48 | https://proceedings.mlr.press/v48/guha16.html |
| `guha2016rrcf` | pages | (absent) | 2712-2721 | https://proceedings.mlr.press/v48/guha16.html |
| `guha2016rrcf` | publisher | (absent) | PMLR | https://proceedings.mlr.press/v48/guha16.html |
| `ding2013iforestasd` | title | An anomaly detection approach based on isolation forest algorithm for streaming data using sliding window | An Anomaly Detection Approach Based on Isolation Forest Algorithm for Streaming Data using Sliding Window (case as registered by the publisher) | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `ding2013iforestasd` | volume | (absent) | 46 | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `ding2013iforestasd` | number | (absent) | 20 | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `ding2013iforestasd` | pages | (absent) | 12-17 | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `ding2013iforestasd` | doi | (absent) | 10.3182/20130902-3-CN-3020.00044 | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `ding2013iforestasd` | publisher | (absent) | Elsevier BV | https://api.crossref.org/works/10.3182/20130902-3-CN-3020.00044 |
| `engelen2021cicids` | title | Troubleshooting an Intrusion Detection Dataset: The CICIDS2017 Case Study | Troubleshooting an Intrusion Detection Dataset: the CICIDS2017 Case Study (lowercase 'the' as registered by IEEE) | https://api.crossref.org/works/10.1109/SPW53761.2021.00009 |
| `engelen2021cicids` | venue | IEEE Security and Privacy Workshops | 2021 IEEE Security and Privacy Workshops (SPW) | https://api.crossref.org/works/10.1109/SPW53761.2021.00009 |
| `engelen2021cicids` | pages | (absent) | 7-12 | https://api.crossref.org/works/10.1109/SPW53761.2021.00009 |
| `engelen2021cicids` | doi | (absent) | 10.1109/SPW53761.2021.00009 | https://api.crossref.org/works/10.1109/SPW53761.2021.00009 |
| `engelen2021cicids` | publisher | (absent) | IEEE | https://api.crossref.org/works/10.1109/SPW53761.2021.00009 |
| `sharafaldin2018cicids` | venue | ICISSP | Proceedings of the 4th International Conference on Information Systems Security and Privacy | https://api.crossref.org/works/10.5220/0006639801080116 |
| `sharafaldin2018cicids` | pages | (absent) | 108-116 | https://api.crossref.org/works/10.5220/0006639801080116 |
| `sharafaldin2018cicids` | doi | (absent) | 10.5220/0006639801080116 | https://api.crossref.org/works/10.5220/0006639801080116 |
| `sharafaldin2018cicids` | publisher | (absent) | SCITEPRESS - Science and Technology Publications | https://api.crossref.org/works/10.5220/0006639801080116 |
| `elkan2001cost` | venue | IJCAI | Proceedings of the Seventeenth International Joint Conference on Artificial Intelligence, IJCAI 2001, Seattle, Washington, USA, August 4-10, 2001 | https://dblp.uni-trier.de/db/conf/ijcai/ijcai2001.html |
| `elkan2001cost` | pages | (absent) | 973--978 | https://dblp.org/search/publ/api?q=The+Foundations+of+Cost-Sensitive+Learning+Elkan&format=json |
| `elkan2001cost` | publisher | (absent) | Morgan Kaufmann | https://dblp.uni-trier.de/db/conf/ijcai/ijcai2001.html |
| `knoblauch2018bocpd` | entry_type | article | inproceedings | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | title | Spatio-temporal Bayesian Online Changepoint Detection with Model Selection | Spatio-temporal Bayesian On-line Changepoint Detection with Model Selection | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | venue | arXiv preprint | Proceedings of the 35th International Conference on Machine Learning | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | volume | (absent) | 80 | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | pages | (absent) | 2718--2727 | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | publisher | (absent) | PMLR | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `knoblauch2018bocpd` | arxiv | (absent) | 1805.05383 | https://export.arxiv.org/api/query?id_list=1805.05383 |
| `fearnhead2007online` | venue | Journal of the Royal Statistical Society: Series B | Journal of the Royal Statistical Society: Series B (Statistical Methodology) [Crossref current container-title: 'Journal of the Royal Statistical Society Series | https://api.crossref.org/works?query.bibliographic=On-line+inference+for+multiple+changepoint+problems+Fearnhead+Liu&rows=3 |
| `fearnhead2007online` | volume | (absent) | 69 | https://api.crossref.org/works?query.bibliographic=On-line+inference+for+multiple+changepoint+problems+Fearnhead+Liu&rows=3 |
| `fearnhead2007online` | number | (absent) | 4 | https://api.crossref.org/works?query.bibliographic=On-line+inference+for+multiple+changepoint+problems+Fearnhead+Liu&rows=3 |
| `fearnhead2007online` | pages | (absent) | 589--605 | https://api.crossref.org/works?query.bibliographic=On-line+inference+for+multiple+changepoint+problems+Fearnhead+Liu&rows=3 |
| `fearnhead2007online` | doi | (absent) | 10.1111/j.1467-9868.2007.00601.x | https://api.crossref.org/works?query.bibliographic=On-line+inference+for+multiple+changepoint+problems+Fearnhead+Liu&rows=3 |
| `barber2023beyond` | title | Conformal Prediction Beyond Exchangeability | Conformal prediction beyond exchangeability | https://api.crossref.org/works/10.1214/23-AOS2276 |
| `barrett2026firce` | entry_type | article | inproceedings | https://api.crossref.org/works/10.1109/smartnets69662.2026.11604738 |
| `barrett2026firce` | venue | arXiv preprint arXiv:2605.01962 | 2026 International Conference on Smart Applications, Communications and Networking (SmartNets) | https://api.crossref.org/works/10.1109/smartnets69662.2026.11604738 |
| `barrett2026firce` | pages | (absent) | 1--9 | https://api.crossref.org/works/10.1109/smartnets69662.2026.11604738 |
| `barrett2026firce` | doi | (absent) | 10.1109/SMARTNETS69662.2026.11604738 | https://api.crossref.org/works/10.1109/smartnets69662.2026.11604738 |
| `barrett2026firce` | publisher | (absent) | IEEE | https://api.crossref.org/works/10.1109/smartnets69662.2026.11604738 |
| `pendlebury2019tesseract` | venue | 28th USENIX Security Symposium | 28th USENIX Security Symposium (USENIX Security 19) | https://www.usenix.org/conference/usenixsecurity19/presentation/pendlebury |
| `pendlebury2019tesseract` | publisher | (absent) | USENIX Association | https://www.usenix.org/conference/usenixsecurity19/presentation/pendlebury |
| `catillo2021critique` | venue | Quality of Information and Communications Technology (QUATIC) | Quality of Information and Communications Technology: 14th International Conference, QUATIC 2021, Algarve, Portugal, September 8-11, 2021, Proceedings | https://api.crossref.org/works/10.1007/978-3-030-85347-1 |
| `catillo2021critique` | volume | (absent) | 1439 (series: Communications in Computer and Information Science) | https://link.springer.com/chapter/10.1007/978-3-030-85347-1_19 |
| `catillo2021critique` | publisher | (absent) | Springer, Cham | https://link.springer.com/chapter/10.1007/978-3-030-85347-1_19 |

## Structural and style changes

| entry | field | old value | new value | source |
|---|---|---|---|---|
| `all entries` | title case | mixed sentence and title case as typed | title case, acronyms and proper nouns brace-protected | editorial choice; ACM-Reference-Format prints titles as typed |
| `beyer2016sre` | author -> editor | author={Beyer, ...} | editor={Beyer, ...} | O'Reilly by-statement: edited by |
| `vovk2005alrw` | entry type | @article with journal={Springer} | @book, publisher Springer, New York | https://doi.org/10.1007/b106715 |
| `barrett2026firce` | entry type | @article, arXiv preprint | @inproceedings, IEEE SmartNets 2026, arXiv id kept as note | https://doi.org/10.1109/SMARTNETS69662.2026.11604738 |
| `knoblauch2018bocpd` | entry type | @article, arXiv preprint (no id) | @inproceedings, ICML 2018 PMLR 80, arXiv id kept as note | https://proceedings.mlr.press/v80/knoblauch18a.html |
| `han2022adbench` | venue | NeurIPS (no pages, no DOI) | NeurIPS 35 Datasets and Benchmarks, pp. 32142--32159, DOI 10.52202/068431-2329 | https://api.crossref.org/works/10.52202/068431-2329 |
| `angelopoulos2024crc` | new entry | (absent) | ICLR 2024, arXiv:2208.02814 as note | https://openreview.net/forum?id=33XGfHLtZg |
| `pyod401, pyod561` | note | open as of 27 August 2026 | open as of 3 September 2026 | https://api.github.com/repos/yzhao062/pyod/issues/401 and /561 |

## Entries removed (uncited in the rebuilt manuscript)

| entry | reason |
|---|---|
| `ahmad2021dlids` | not cited; the manuscript cites no IDS survey and conducted none |
| `khraisat2019survey` | not cited; same reason |
| `beyer2018sreworkbook` | not cited; the SRE error-budget sentence cites beyer2016sre only |
| `bhatia2021mstream` | not cited; MStream is not mentioned anywhere in the manuscript |
| `bhatia2022memstream` | not cited; MemStream is not mentioned anywhere in the manuscript |
| `yoon2022arcus` | not cited; ARCUS is not mentioned anywhere in the manuscript |
| `bifet2007adwin` | not cited; the manuscript has no concept-drift or ADWIN sentence |
| `gama2014conceptdrift` | not cited; same reason |
| `fawcett1997activity` | not cited; no fraud-detection or activity-monitoring sentence exists |
| `moustafa2015unsw` | not cited; the UNSW-NB15 results are withdrawn and the dataset is not named in the body |
| `moustafa2016evaluation` | not cited; same reason |

## Additions (2026-09-03), each verified before entry

| entry | verified record | hook in the manuscript |
|---|---|---|
| `sommer2010outside` | IEEE S&P 2010, pp. 305--316, DOI 10.1109/SP.2010.25 (Crossref + DBLP conf/sp/SommerP10) | Related Work, evaluation-pitfalls paragraph, after Arp et al. |
| `liu2022errorprevalence` | IEEE CNS 2022, pp. 254--262, DOI 10.1109/CNS56114.2022.9947235 (Crossref + DBLP conf/cns/LiuELEJ22); no preprint exists | Related Work, the Engelen corrected-release sentence |
| `lanvin2022errors` | CRiSIS 2022, LNCS 13857, pp. 18--33, published 2023, DOI 10.1007/978-3-031-31108-6_2 (Crossref + DBLP conf/crisis/LanvinGHMMT22); the year field is the proceedings year | same hook |
| `apruzzese2023sok` | IEEE EuroS&P 2023, pp. 592--614, DOI 10.1109/EuroSP57164.2023.00042 (Crossref); version of record of arXiv:2305.00550 | Related Work, after the Apruzzese, Pajola and Conti cross-evaluation sentence |
| `mcdermott2024closerlook` | NeurIPS 2024 version of record confirmed: Advances in NeurIPS 37, pp. 44102--44163, DOI 10.52202/079017-1400 (Crossref, proceedings.neurips.cc); arXiv:2401.06091 kept as note | Related Work, metrics paragraph after Axelsson |
| `wu2023flawed` | IEEE TKDE 35(3), pp. 2421--2429, 2023, DOI 10.1109/TKDE.2021.3112126 (Crossref, IEEE Xplore) | Related Work, after the Cao et al. benchmark sentence |
| `campos2016evaluation` | DMKD 30(4), pp. 891--927, 2016, DOI 10.1007/s10618-015-0444-8 (Crossref); no preprint exists | ECOD section, after the cross-study comparability sentence |
| `bates2021rcps` | JACM 68(6), Article 43, 2021, DOI 10.1145/3478535 (Crossref + DBLP journals/jacm/BatesALMJ21); arXiv:2101.02703 is the preprint | the Conformal Risk Control sentence |

Title casing follows this file's convention (title case, acronyms braced), so
the published lowercase forms "NIDS datasets", "Benchmarks are Flawed and are
Creating", "Distribution-free, Risk-controlling" and "under Class Imbalance"
appear here in title case. DOIs and all other fields are as registered.

## Considered and excluded (2026-09-03)

| work | reason |
|---|---|
| D'hooge et al., the two feature-leakage papers on CICIDS-family datasets | feature leakage is a different mechanism from stream assembly and this paper makes no leakage claim, so there is no sentence for them to support |
| the ACM REP 2025 paper on provenance for reproducible IDS experiments | reproducibility tooling rather than an evaluation-protocol finding; the reproducibility point this paper makes is carried by Olszewski et al. and by its own artifact |
| the nonconform tooling preprint | a software preprint for conformal tooling; this paper proposes no conformal method and relies on no result from it |

## Preprints kept as preprints (no version of record found on 2026-09-03)

`adams2007bocpd` (arXiv only; DataCite DOI added), `vandeburg2020evaluation`
(arXiv v3, no journal record), `gurjar2026tailrisk` (arXiv; the arXiv comment
says under review, which the entry does not repeat), `biswas2026protocol`
(Preprints.org v1; no v2 and no journal relation), `moczkodan2026transformers`
(arXiv; no non-arXiv location).

## Additions (2026-09-06), each verified before entry

| entry | verified record | hook in the manuscript |
|---|---|---|
| `gama2013prequential` | Machine Learning 90(3), pp. 317--346, 2013, DOI 10.1007/s10994-012-5320-9 (Crossref; the record's online date is 2012, the volume year is 2013 and the entry carries the volume year) | Table 2, the update-timing row, where the prequential protocol is named |
| `tatbul2018precision` | Advances in NeurIPS 31 (NeurIPS 2018), pp. 1924--1934 (DBLP conf/nips/TatbulLZAG18; proceedings.neurips.cc hash 8f468c873a32bb0619eaeb2050ba45d1); arXiv:1803.03639 kept as note; NeurIPS 2018 papers carry no Crossref DOI, so none is entered | Table 2, the metric row, with the sentence that flow-wise AP is the convention of the compared work and event-based evaluation is future work |
| `kunsch1989jackknife` | The Annals of Statistics 17(3), 1989, DOI 10.1214/aos/1176347265 (Crossref: title, journal, volume, issue, year, author as "Kunsch"); pages 1217--1241 from the publisher page (projecteuclid.org, citation_firstpage/lastpage), which Crossref does not carry; Crossref and the Euclid meta tags give the ASCII form "Kunsch", and the umlaut follows the author's printed byline, corroborated by OpenAlex and zbMATH 0684.62035 | Threats to Validity, the moving-block bootstrap description (added 2026-09-06, final read) |

## Second referee round (2026-09-07)

| entry | action | verified record | hook |
|---|---|---|---|
| `manzhos2026ap` | added | Modern Stochastics: Theory and Applications 13(3), pp. 357--374, 2026, DOI 10.15559/26-VMSTA298 (Crossref: title, journal, pages, authors with ORCIDs, CC BY; the deposit carries no volume or issue, which come from the publisher page's citation meta tags and the published PDF header); arXiv:2511.02571 kept as note. Theorem 1 (eq. 4, p. 362) gives the expectation of AP at cutoff k under a uniformly random ranking; the full-list expectation the manuscript prints is its k = n case, which the paper does not print itself, and the manuscript says so | Table 2, chance-level row |
| `angelopoulos2024crc` | removed | uncited after the conformal paragraph of Section 11 was deleted (second report, MAJOR 6) | none |
| `bates2021rcps` | removed | uncited for the same reason | none |
